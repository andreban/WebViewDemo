mainContainer = document.getElementById("main");

        const childDiv = document.createElement('div');


         childDiv.innerHTML = `
                <div>
                    <p>Miusov, as a man man of breeding and deilcacy, could not but feel some inwrd qualms,
                    </p>
                    <div class="cloud-image">
                        <img src="img/successCloudNew.svg" />
                    </div>
                    <div class="content">
                        <div class="tweet-container">
                        <a href="http://twitter.com/intent/tweet/?text=I%20just%20created%20a%20new%20HTML%20website%20on%20Azure%20using%20Azure%20DevOps%20Project&hashtags=AzureDevOpsProject%2CVSTS%20%40Azure%20%40VSTS">
                            <img src="img/tweetThis.svg" />
                        </a>
                    </div>
                        <div class="content-body">
                            <div class="success-text">Success!</div>
                            <div class="description line-1"> Azure DevOps Project has been successfully setup</div>
                            <div class="description line-2"> Your HTML app is up and running on Azure</div>
                            <div class="next-steps-container">
                                <div class="next-steps-header">Next up</div>
                                <div class="next-steps-body">
                                    <div class="step">
                                        <div class="step-icon">
                                            <img src="img/cloneWhite.svg">
                                        </div>
                                        <div class="step-text"><a href="https://go.microsoft.com/fwlink/?linkid=862409">Clone your code repository and start developing your application on IDE of your choice</a></div>
                                    </div>
                                    <div class="step">
                                        <div class="step-icon">
                                            <img src="img/deployWhite.svg">
                                        </div>
                                        <div class="step-text"><a href="https://go.microsoft.com/fwlink/?linkid=862410">View your CI/CD pipeline on Visual Studio Team Services and customize it as per your needs</a></div>
                                    </div>
                                    <div class="step">
                                        <div class="step-icon">
                                            <img src="img/stackWhite.svg">
                                        </div>
                                        <div class="step-text"><a href="http://portal.azure.com">View your service stack in the Azure Portal</a></div>
                                    </div>
                                    <div class="step">
                                        <div class="step-icon">
                                            <img src="img/lightbulbWhite.svg">
                                        </div>
                                        <div class="step-text"><a href="https://go.microsoft.com/fwlink/?linkid=862126">Learn more about all you can do with Azure projects by visiting the documentation</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
         `;

        mainContainer.appendChild(childDiv);